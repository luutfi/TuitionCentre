
public class Name {
    
    private String fName;
    private String lName;
    private String mName;
    
    //constructor
    //no return, name same as class
    public Name(){
        
    }
    public Name(String fName, String mName, String lName){
       this.fName = fName;
       this.mName = mName;
       this.lName = lName;
    }
    
    public void setFName(String fName){
        // "this" refers to class attributes 
        this.fName = fName;
    }
    
    public String getFName(){
        return fName;
    }
        
    public void setMName(String mName){
        
        // "this" refers to class attributes 
        this.mName = mName;
    }
    
        public String getMName(){
        return mName;
    }
    
    public void setLName(String fName){
        
        // "this" refers to class attributes 
        this.lName = lName;
    }
    
        public String getLName(){
        return lName;
    }
}